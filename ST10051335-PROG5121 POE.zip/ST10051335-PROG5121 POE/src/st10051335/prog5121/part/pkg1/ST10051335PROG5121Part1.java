package st10051335.prog5121.part.pkg1;
import java.util.Scanner;
import javax.swing.JOptionPane;


public class ST10051335PROG5121Part1 {
    
   
    public static void main(String[] args) {
      Login LoginFrame = new Login();
      LoginFrame.setVisible(true);
      LoginFrame.pack();
      LoginFrame.setLocationRelativeTo(LoginFrame);
     
            try (Scanner scanner = new Scanner(System.in)) {
            System.out.print(" Enter user name => ");
            String userName = scanner.nextLine();

            System.out.print(" Enter password => ");
            String password = scanner.nextLine();

            if ("Ty_".equals(userName) && "Tyrique031#".equals(password)) {
                System.out.println(" Welcome to EasyKanban");
            } else {
                System.out.println(" Username must contain an underscore and password must be more than 8 characters long and contain a capital,number and special character ");
            }
            { JOptionPane.showMessageDialog(null, "Invalid details please try again");}
     
        }
            
        }

    public static boolean checkPassword(String password)
    {
        boolean containsDigits = false;
        boolean containsSpace = false;
         
        int passwordLength = password.length();
        for (int i = 0; i < passwordLength; i++) { 
            char character = password.charAt(i);
            if (Character.isWhitespace(character))
            { containsSpace = true;}
            if (Character.isDigit(character))
            { containsDigits = true;}
        }
        
        if (containsDigits && containsSpace)
        { return true;}
        else{ return false;}
    }
    
    public static void options()
    {
        int option =0;
       
        while (option != 3) {
            
            String tasks = JOptionPane.showInputDialog(null, "Plese select one of the following options:(enter the number of your selection)\n"
                    + "1: Add task\n2: Coming soon\n3: Quit");
            option = Integer.parseInt(tasks);
            switch (option) {
                case 1:
                   String transactions = JOptionPane.showInputDialog(null, "Plese enter the number of tasks you want to add");
                   int numTransactions = Integer.parseInt(transactions); 
                   double totalAmount = createTransaction(numTransactions);
                   JOptionPane.showMessageDialog(null,"Total amount of task"+ totalAmount);
                break;
                case 2:
                    JOptionPane.showMessageDialog(null,"Coming soon");
                break;
                case 3:
                    JOptionPane.showMessageDialog(null,"Goodbye");
                    System.exit(0);
                break;
        }
        }
        
    }
    
    public static double createTransaction(int numTransactions)
    {
        double total=0;
        for (int i=0; i< numTransactions; i++)
        {
            String transactionName = JOptionPane.showInputDialog(null, "Plese enter the NAME of task" + (i+1));
            String description = JOptionPane.showInputDialog(null, "Plese enter the DESCRIPTION of task" + (i+1)); 
            String recipient = JOptionPane.showInputDialog(null, "Plese enter the RECIPIENT of task" + (i+1));
            String amount = JOptionPane.showInputDialog(null, "Plese enter the AMOUNT of task" + (i+1));
            int transactionAmount = Integer.parseInt(amount); 
            String status = JOptionPane.showInputDialog(null, "Plese select the STATUS of task" + (i+1) 
                    +"\n1: Pending\n2:Completed");
            int option = Integer.parseInt(status);
            
            String transactionStatus = retrieveStatus(option);
            
            Transactions transaction = new Transactions(transactionName, description, recipient, transactionAmount, transactionStatus);
            String output = transaction.outputDetails();
            JOptionPane.showMessageDialog(null, output);
            total = transaction.getTotalAmount();
        }
 
        return total;
            
    }
    public static String retrieveStatus(int option)
    { 
        String transactionStatus = "";
              switch (option) {
                case 1:
                   transactionStatus = "Pending";
                break;
                case 2:
                    transactionStatus = "Finalised"; 
                break;
    }
              return  transactionStatus;
    }
    
}
    

     
     
     
    
      
          
      
    

    