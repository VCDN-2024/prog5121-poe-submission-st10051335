package st10051335.prog5121.part.pkg1;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;



public class unittestingTest {
    
    public unittestingTest() {
  
    }
    
    AddTask task = new AddTask();
    
    @Test
    public void testCheckTaskDescription() {
        String validDescription = "This is a valid task description.";
        assertTrue(task.checkTaskDescription(validDescription));
    }

    @Test
    public void testCheckTaskDescriptionWrong() {
        String invalidDescription = "This task description is way too long and exceeds the fifty character limit.";
        assertFalse(task.checkTaskDescription(invalidDescription));
    }

    @Test
    public void testCreateTaskID() {
        String taskName = "TaskName";
        int taskNumber = 1;
        String developerName = "John Doe";
        String expectedTaskID = "TA:1:DOE";
        assertEquals(expectedTaskID, task.createTaskID(taskName, taskNumber, developerName));
    }

    @Test
    public void testPrintTaskDetails() {
        String taskStatus = "To Do";
        String developerDetails = "John Doe";
        int taskNumber = 1;
        String taskName = "TaskName";
        String taskDescription = "A task description.";
        String taskID = "TA:1:DOE";
        int taskDuration = 5;

        String expectedDetails = "Task status: To Do\n" +
                "Developer details: John Doe\n" +
                "Task number: 1\n" +
                "Task name: TaskName\n" +
                "Task description: A task description.\n" +
                "Task ID: TA:1:DOE\n" +
                "Duration: 5 hours";

        assertEquals(expectedDetails, task.printTaskDetails(taskStatus, developerDetails, taskNumber, taskName, taskDescription, taskID, taskDuration));
    }

    @Test
    public void testReturnTotalHours() {
        task.addTasks();
        assertEquals(10, task.returnTotalHours()); 
    }

    @Test
    public void testGetInput() {
    }

    @Test
    public void testShowMenu() {
    }

    @Test
    public void testOptions() {
    }

    @Test
    public void testAddTasks() {
    }

    @Test
    public void testDisplay() {
        String expectedOutput = "Tasks that are done:\n" +
                                "\nTask name:\tCreate Reports" +
                                "\nDevelopers Name:\tSamantha Paulson" +
                                "\nTask Duration:\t2";

        assertEquals(expectedOutput, task.display());
    }

    @Test
    public void testMaxDuration() {
        String expectedDetails = 
                "\nTask name:\tAdd Arrays" +
                "\nDevelopers Name:\tGlenda Oberholzer" +
                "\nTask Duration:\t11";

        assertEquals(expectedDetails, task.MaxDuration());
    }

    @Test
    public void testSearch() {
        String Name = "Create Login";
        String expectedDetails = "Create Login\n"+
                "Mike Smith";
        
        assertEquals(expectedDetails, task.Search(Name));
    }

    @Test
    public void testSearchDeveloperDetails() {
        String developerDetails = "Samantha Paulson";
        String expectedDetails = "Create Reports\n"+
                "Samantha Paulson";
        assertEquals(expectedDetails, task.SearchDeveloperDetails(developerDetails));
    }

    @Test
    public void testDelete() {
        assertTrue(task.Delete("Create Reports"));
        assertEquals(new String[]{"Mike Smith", "Edward Harrison", "Glenda Oberholzer"}, task.arrDeveloper);
        assertEquals(new String[]{"Create Login", "Create Add Features", "Add Arrays"}, task.arrTaskName);
        assertEquals(new int[]{5, 8, 11}, task.arrtaskDuration);
        assertEquals(new String[]{"To Do", "Doing", "To Do"}, task.arrtaskStatus);
    }
}

